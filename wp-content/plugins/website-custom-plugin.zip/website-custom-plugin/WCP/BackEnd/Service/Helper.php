<?php


include_once(dirname(__FILE__)."/View.php");

// helper functions go in here
class WCP_BackEnd_Service_Price_Helper {
}
?>
