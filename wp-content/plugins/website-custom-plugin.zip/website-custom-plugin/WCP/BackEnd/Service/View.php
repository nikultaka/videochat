<?php


class WCP_BackEnd_Service_Price_View {

}
?>
