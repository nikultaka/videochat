<?php

class WCP_VideoChat_Controller {

    public function videochat_home() {

        if (!is_user_logged_in()) {
            wp_redirect('my-account');
            exit;  
        }        

        require_once plugin_dir_path(dirname(__FILE__)) . 'VideoChat/HTML/home.php';
        $s = ob_get_contents();
        ob_end_clean();   
        return $s;

    }

    public function store_data() {

        $result_array = array();        
        echo json_encode($result_array);  
        exit;              

    }

    public function get_online_user() {
        global $wpdb;
        $user_id = '';
        $table = $wpdb->prefix.'online_users';
        if(isset($_POST['user_id'])) {      
            $user_id = $_POST['user_id']; 
            $wpdb->query(" update ".$table." set status = '1',gm_updated = NOW() where user_id = ".$user_id);   
            $userData = $wpdb->get_results("select * from ".$table." where status = '1' and user_id != ".$user_id." ");
            $stream_array = array();
            if(!empty($userData)) {
                foreach($userData as $key => $value) {
                    $stream_id = str_replace('{','',trim($value->stream_id));
                    $stream_id = str_replace('}','',$stream_id);
                    $stream_array[] = $stream_id;
                }   
            }  
            echo json_encode(array("status"=>1,'stream_data'=>$stream_array));
        } else {  
            echo json_decode(array("status"=>0));
        }                 
        exit;               
    }

    public function add_stream_user() {     
        global $wpdb;
        $user_id = '';
        $table = $wpdb->prefix.'online_users';
        if(isset($_POST['user_id'])) {      
            $user_id = $_POST['user_id'];  
            $stream_id = $_POST['stream_id'];  
            $userData = $wpdb->get_results("select * from ".$table." where user_id =".$user_id);

            if(!empty($userData)) {
                $wpdb->query(" update ".$table." set status = '1',gm_updated = NOW() where user_id = ".$user_id);
            } else {
                $wpdb->insert($table,array('stream_id'=>$stream_id,'user_id'=>$user_id,'status'=>1,'gm_created'=>current_time('mysql', 1),'gm_updated'=>current_time('mysql', 1)));    
            }
            
            echo json_encode(array("status"=>1));
        } else {
            echo json_decode(array("status"=>0));
        }        
        exit;  
    }        

}

$WCP_VideoChat_Controller = new WCP_VideoChat_Controller();
add_shortcode('VideoChat', array($WCP_VideoChat_Controller, 'videochat_home'));
/// Ajax
add_action('wp_ajax_nopriv_WCP_VideoChat_Controller::store_data', Array($WCP_VideoChat_Controller, 'store_data'));
add_action('wp_ajax_WCP_VideoChat_Controller::store_data', Array($WCP_VideoChat_Controller, 'store_data'));

add_action('wp_ajax_nopriv_WCP_VideoChat_Controller::get_online_user', Array($WCP_VideoChat_Controller, 'get_online_user'));
add_action('wp_ajax_WCP_VideoChat_Controller::get_online_user', Array($WCP_VideoChat_Controller, 'get_online_user'));

add_action('wp_ajax_nopriv_WCP_VideoChat_Controller::add_stream_user', Array($WCP_VideoChat_Controller, 'add_stream_user'));
add_action('wp_ajax_WCP_VideoChat_Controller::add_stream_user', Array($WCP_VideoChat_Controller, 'add_stream_user'));
?>